package org.json.junit.data;

/**
 * An enum with no methods or data
 */
public enum MyEnum {
    VAL1,
    VAL2,
    VAL3;
}
